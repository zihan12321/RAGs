from ragas import evaluate
import os
import csv
import pandas as pd
from datasets import Dataset
from datasets import load_dataset
os.environ["OPENAI_API_KEY"] = "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"
# os.environ['OPENAI_API_BASE']="http://33.1.231.248:6091/v1"
# os.environ['OPENAI_API_KEY']="EMPTY"

filepath = "./icbu-tars-13borigin_llama13b_llm2c_0901_gptgenerate.csv"

# 加载CSV文件
dataset = load_dataset('csv', data_files=filepath)

# 处理数据
def process_data_to_dataset(example):
    # 将字符串列表转换为实际的列表
    # example['ground_truths'] = "'" + example['ground_truths'] + "'" 
    example['ground_truths'] = eval(example['ground_truths'])
    example['contexts'] = eval(example['contexts'])
    return example

# 使用map函数处理数据
dataset = dataset.map(process_data_to_dataset)

# 查看数据
print(dataset)
train_dataset = dataset['train']
results = evaluate(train_dataset)
print(results)